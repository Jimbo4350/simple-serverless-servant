var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'jimbo4350',
applicationName: 'minimal-example-rds',
appUid: 'RfYgf4g6fvC9Dg3nMV',
tenantUid: 'Ltvhlpjrs98Z8Fx2Lb',
deploymentUid: '7bb50cab-02ed-420b-a460-770d9166de5e',
serviceName: 'serverless-minimal-example-rds',
stageName: 'dev',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'serverless-minimal-example-rds-dev-apigw', timeout: 6}
try {
  const userHandler = require('./serverless-haskell-example.js')
  module.exports.handler = serverlessSDK.handler(userHandler.apigw, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
